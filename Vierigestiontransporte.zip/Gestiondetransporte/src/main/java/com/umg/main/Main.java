package com.umg.main;

import com.umg.transporte.Bus;
import com.umg.transporte.Avion;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int opcion;

        Bus miBus = new Bus("P123BTP", "Rojo", "Mercedes", "2022", 45);
        Avion miAvion = new Avion("vieri-001", "Blanco", "Boeing", "747", 4);

        do {
            System.out.println("  Sistema de transporte vieri");
            System.out.println("1. Ver datos del Bus");
            System.out.println("2. Ver datos del Avión");
            System.out.println("3. Arrancar Bus");
            System.out.println("4. Arrancar Avión");
            System.out.println("5. Mostrar capacidad de Bus");
            System.out.println("6. Mostrar motores del Avión");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opcion que desea: ");
            opcion = entrada.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Información del Bus");
                    miBus.verDatos();
                    break;

                case 2:
                    System.out.println("Información del Avión");
                    miAvion.verDatos();
                    break;

                case 3:
                    System.out.println("Bus en accion");
                    miBus.arrancar();
                    break;

                case 4:
                    System.out.println("Avión en accioon ");
                    miAvion.arrancar();
                    break;

                case 5:
                    System.out.println("Capacidad del Bus ");
                    miBus.mostrarCapacidad();
                    break;

                case 6:
                    System.out.println("Motores del Avión");
                    miAvion.mostrarMotores();
                    break;

                case 0:
                    System.out.println("Saliendo del sistema ¡Gracias!");
                    break;

                default:
                    System.out.println("Opción no válida, intenta de nuevo.");
            }

        } while (opcion != 0);
    }
}
