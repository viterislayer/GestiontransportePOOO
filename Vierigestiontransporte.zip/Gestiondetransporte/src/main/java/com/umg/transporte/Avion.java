package com.umg.transporte;

public class Avion extends Transporte {
    private int motores;

    public Avion(String placa, String color, String marca, String modelo, int motores) {
        super(placa, color, marca, modelo);
        this.motores = motores;
    }

    public void mostrarMotores() {
        System.out.println("Este avión tiene " + motores + " motores.");
    }
}
