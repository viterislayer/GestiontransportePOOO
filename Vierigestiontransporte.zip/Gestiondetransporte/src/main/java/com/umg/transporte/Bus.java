package com.umg.transporte;

public class Bus extends Transporte {
    private int capacidad;

    public Bus(String placa, String color, String marca, String modelo, int capacidad) {
        super(placa, color, marca, modelo);
        this.capacidad = capacidad;
    }

    public void mostrarCapacidad() {
        System.out.println("Capacidad del bus: " + capacidad + " pasajeros.");
    }
}
