package com.umg.transporte;

public class Transporte {
    protected String placa;
    protected String color;
    protected String marca;
    protected String modelo;

    public Transporte(String placa, String color, String marca, String modelo) {
        this.placa = placa;
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public void arrancar() {
        System.out.println("El transporte está arrancando.");
    }

    public void verDatos() {
        System.out.println("Placa: " + placa + " | Marca: " + marca + " | Modelo: " + modelo + " | Color: " + color);
    }
}
